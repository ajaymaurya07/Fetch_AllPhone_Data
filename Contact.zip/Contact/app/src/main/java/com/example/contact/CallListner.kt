package com.example.contact

interface CallListner {
    fun onCallBtnClick(mob:String)

}

