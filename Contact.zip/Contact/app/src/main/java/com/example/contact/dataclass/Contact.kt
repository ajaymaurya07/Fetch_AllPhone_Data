package com.example.contact.dataclass

data class Contact(
    var id:String,
    var name:String,
    var phoneno:String
)
